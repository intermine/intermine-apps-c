  var mediator = _.extend({}, Backbone.Events);
  module.exports = mediator;