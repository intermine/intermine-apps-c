var $;
      
$ = window.jQuery
      
module.exports = {
        $: $,
        _: _,
        Backbone: Backbone,

};